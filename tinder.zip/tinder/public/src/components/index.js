export { default as Counter } from "./counter/counter.js";
export {default as MyPost} from "./insta/insta.js";
