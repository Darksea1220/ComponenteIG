const data = [
    {
        "profileimg":".././images/perfil.png",
        "name":"Duglon",
        "ubication":"Cali",
        "post":".././images/narutowapo.jpg",
        "description":`El otro día estaba tratando de conquistar una programadora...
        no se de-Java`,
        
    },
    {
        "profileimg":".././images/chad.jpeg",
        "name":"Larry Capija",
        "ubication":"Chupamestepenco",
        "post":".././images/papagumball.jpeg",
        "description":`Tunometescabrasarabambiche nena`,
    },
    {
        "profileimg":".././images/wchad.jpg",
        "name":"Rosa Melano",
        "ubication":"Kissing-Alemania",
        "post":".././images/Ros.png",
        "description":`A su servicio Amo`,
    },
    {
        "profileimg":".././images/ahe.jpeg",
        "name":"Elba Gina",
        "ubication":"Hell-Noruega",
        "post":".././images/postahe.jpeg",
        "description":`Siempre caliente, nunca incaliente`,
    },
]
export default data;