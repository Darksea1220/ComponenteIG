import * as components from './components/index.js';
import data from './components/data.js';

console.log(data);

class AppContainer extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' }); 
  }

  connectedCallback() {
    this.render();
  }

  render() {
    data.forEach((e) => {
      this.shadowRoot.innerHTML += `
      <my-post profileimg="${e.profileimg}" name="${e.name}" ubication="${e.ubication}" post="${e.post}" description="${e.description}"</my-post>
      `;
    })
  }
}
customElements.define('app-container', AppContainer);
